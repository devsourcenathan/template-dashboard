export class BerryConfig {
  static layout: string = 'vertical';
  static isCollapse_menu: boolean = false;
  static fontFamily: string = 'Roboto'; // Roboto, poppins, inter
}
